import { Router } from "express";
import { pool } from "@workspace/db";
import { DeSearchBody, DeSuggestQueryParams } from "@workspace/api-zod";

const router = Router();

function normalize(text: string): string {
  return text
    .replace(/[أإآا]/g, "ا")
    .replace(/[يى]/g, "ي")
    .replace(/ة/g, "ه")
    .replace(/[\u064B-\u065F]/g, "")
    .toLowerCase()
    .trim();
}

function buildAnswer(query: string, count: number, results: Record<string, unknown>[]): string | null {
  if (count === 0) return `لم نجد نتائج لـ "${query}" في قاعدة بياناتنا.`;
  const top = results[0] as { name: string; specialty?: string; region?: string };
  const specialty = top.specialty || "";
  const region = top.region || "";
  if (count === 1) return `وجدنا ${specialty ? specialty + " " : ""}واحد${region ? " في " + region : ""}: ${top.name}`;
  return `وجدنا ${count} نتيجة${specialty ? " في " + specialty : ""}. أفضل نتيجة: ${top.name}${region ? " — " + region : ""}`;
}

router.post("/de/search", async (req, res) => {
  const parsed = DeSearchBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request" });
    return;
  }

  const { query, specialty, region, category, limit = 20 } = parsed.data;
  const norm = normalize(query);
  const safeLimit = Math.min(limit ?? 20, 50);

  try {
    const conditions: string[] = [];
    const params: unknown[] = [];
    let idx = 1;

    if (norm) {
      // Split into words — each word must appear somewhere across all fields (AND logic)
      // Search both the normalized form AND the original word to handle ة/ه and أ/ا differences
      const normWords = norm.split(/\s+/).filter((w) => w.length > 1);
      const origWords = query.trim().split(/\s+/).filter((w) => w.length > 1);
      for (let wi = 0; wi < normWords.length; wi++) {
        const nw = normWords[wi];
        const ow = origWords[wi] ?? nw;
        if (nw === ow.toLowerCase()) {
          conditions.push(`(
            name ILIKE $${idx} OR address ILIKE $${idx} OR
            specialty ILIKE $${idx} OR category ILIKE $${idx} OR
            region ILIKE $${idx} OR governorate ILIKE $${idx} OR
            doctor_name ILIKE $${idx}
          )`);
          params.push(`%${nw}%`);
          idx++;
        } else {
          conditions.push(`(
            name ILIKE $${idx} OR name ILIKE $${idx + 1} OR
            address ILIKE $${idx + 1} OR
            specialty ILIKE $${idx} OR specialty ILIKE $${idx + 1} OR
            category ILIKE $${idx} OR category ILIKE $${idx + 1} OR
            region ILIKE $${idx + 1} OR governorate ILIKE $${idx + 1} OR
            doctor_name ILIKE $${idx} OR doctor_name ILIKE $${idx + 1}
          )`);
          params.push(`%${nw}%`);
          params.push(`%${ow}%`);
          idx += 2;
        }
      }
    }

    if (specialty) {
      conditions.push(`specialty ILIKE $${idx}`);
      params.push(`%${specialty}%`);
      idx++;
    }

    if (region) {
      conditions.push(`(region ILIKE $${idx} OR governorate ILIKE $${idx})`);
      params.push(`%${region}%`);
      idx++;
    }

    if (category) {
      conditions.push(`category ILIKE $${idx}`);
      params.push(`%${category}%`);
      idx++;
    }

    conditions.push(`LENGTH(name) > 4`);

    const where = conditions.length > 0 ? `WHERE ${conditions.join(" AND ")}` : "";

    const countResult = await pool.query(
      `SELECT COUNT(*) FROM entities ${where}`,
      params
    );
    const total = parseInt(countResult.rows[0].count, 10);

    params.push(safeLimit);
    const dataResult = await pool.query(
      `SELECT id, name, phone, address, specialty, category, region, governorate, doctor_name, whatsapp, facebook, source
       FROM entities ${where}
       ORDER BY
         CASE WHEN phone IS NOT NULL AND phone != '' THEN 0 ELSE 1 END,
         CASE WHEN whatsapp IS NOT NULL THEN 0 ELSE 1 END,
         name
       LIMIT $${idx}`,
      params
    );

    const results = dataResult.rows;
    const answer = buildAnswer(query, total, results);

    res.json({ results, total, query, answer });
  } catch (err) {
    req.log.error({ err }, "DE search error");
    res.status(500).json({ error: "Search failed" });
  }
});

router.get("/de/stats", async (req, res) => {
  try {
    const [totalRes, phoneRes, verifiedRes, specRes, regRes, catRes] = await Promise.all([
      pool.query("SELECT COUNT(*) FROM entities"),
      pool.query("SELECT COUNT(*) FROM entities WHERE phone IS NOT NULL AND phone NOT IN ('-','01000000000','')"),
      pool.query("SELECT COUNT(*) FROM entities WHERE status = 'Verified'"),
      pool.query(`SELECT specialty as name, COUNT(*) as count FROM entities WHERE specialty IS NOT NULL AND specialty != '' AND specialty ~ '[\\u0600-\\u06FF]' GROUP BY specialty ORDER BY count DESC LIMIT 10`),
      pool.query(`SELECT name, SUM(count) as count FROM (
        SELECT governorate as name, COUNT(*) as count FROM entities
        WHERE governorate IS NOT NULL AND governorate NOT IN ('','غير محدد','None','active')
        AND governorate ~ '[\\u0600-\\u06FF]'
        GROUP BY governorate
        UNION ALL
        SELECT region as name, COUNT(*) as count FROM entities
        WHERE governorate IS NULL AND region IS NOT NULL
        AND region NOT IN ('','غير محدد','None','active')
        AND region ~ '[\\u0600-\\u06FF]'
        AND region NOT LIKE '%إكلينيك%' AND region NOT LIKE '%شوارع%'
        AND LENGTH(region) < 30
        GROUP BY region
      ) t GROUP BY name ORDER BY count DESC LIMIT 10`),
      pool.query(`SELECT category as name, COUNT(*) as count FROM entities WHERE category IS NOT NULL AND category != '' GROUP BY category ORDER BY count DESC LIMIT 12`),
    ]);

    res.json({
      total_entities: parseInt(totalRes.rows[0].count, 10),
      total_with_phone: parseInt(phoneRes.rows[0].count, 10),
      total_verified: parseInt(verifiedRes.rows[0].count, 10),
      top_specialties: specRes.rows.map((r: { name: string; count: string }) => ({ name: r.name, count: parseInt(r.count, 10) })),
      top_regions: regRes.rows.map((r: { name: string; count: string }) => ({ name: r.name, count: parseInt(r.count, 10) })),
      category_breakdown: catRes.rows.map((r: { name: string; count: string }) => ({ name: r.name, count: parseInt(r.count, 10) })),
    });
  } catch (err) {
    req.log.error({ err }, "DE stats error");
    res.status(500).json({ error: "Stats failed" });
  }
});

router.get("/de/suggest", async (req, res) => {
  const parsed = DeSuggestQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid params" });
    return;
  }

  const q = parsed.data.q;

  try {
    if (!q || q.trim().length === 0) {
      // Return popular specialties as suggestions
      const result = await pool.query(
        `SELECT specialty as text, 'specialty' as type FROM entities WHERE specialty IS NOT NULL AND specialty != '' AND specialty ~ '[\\u0600-\\u06FF]' GROUP BY specialty ORDER BY COUNT(*) DESC LIMIT 8`
      );
      res.json(result.rows);
      return;
    }

    const norm = normalize(q);
    const result = await pool.query(
      `SELECT DISTINCT name as text, 'entity' as type FROM entities
       WHERE name ILIKE $1 AND LENGTH(name) > 4
       LIMIT 6
       UNION
       SELECT DISTINCT specialty as text, 'specialty' as type FROM entities
       WHERE specialty ILIKE $1 AND specialty IS NOT NULL
       LIMIT 4`,
      [`%${norm}%`]
    );
    res.json(result.rows);
  } catch (err) {
    req.log.error({ err }, "DE suggest error");
    res.json([]);
  }
});

router.post("/de/import", async (req, res) => {
  const rows = req.body;
  if (!Array.isArray(rows)) {
    res.status(400).json({ error: "Expected JSON array" });
    return;
  }

  function fixPhone(p: unknown): string | null {
    if (!p || p === "None" || p === "-" || p === "null") return null;
    let s = String(p).replace(/\s+/g, "").replace(/[^0-9+]/g, "");
    if (s.startsWith("2010") || s.startsWith("2011") || s.startsWith("2012") || s.startsWith("2015")) s = "0" + s.slice(2);
    if (s.length === 10 && !s.startsWith("0")) s = "0" + s;
    if (s === "01000000000" || s.length < 10) return null;
    return s;
  }

  function clean(v: unknown): string | null {
    if (!v || v === "None" || v === "null" || v === "غير محدد") return null;
    const s = String(v).trim();
    return s.length > 0 ? s : null;
  }

  const JUNK = new Set(["scrap_data","discovered_links","analyzed_links","None","null",""]);

  let inserted = 0;
  let skipped = 0;

  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    for (const row of rows) {
      const name = clean(row.name);
      if (!name || name.length < 4 || JUNK.has(name)) { skipped++; continue; }

      const phone = fixPhone(row.phone);
      const whatsapp = fixPhone(row.whatsapp);
      const address = clean(row.address);
      const specialty = clean(row.specialty);
      const category = clean(row.category);
      const region = clean(row.region);
      const governorate = clean(row.governorate);
      const doctor_name = clean(row.doctor_name);
      const facebook = clean(row.facebook);
      const status = clean(row.status) ?? "Verified";

      await client.query(
        `INSERT INTO entities (name, phone, address, specialty, category, region, governorate, doctor_name, whatsapp, facebook, source, status)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,'titan',$11)
         ON CONFLICT DO NOTHING`,
        [name, phone, address, specialty, category, region, governorate, doctor_name, whatsapp, facebook, status]
      );
      inserted++;
    }
    await client.query("COMMIT");
  } catch (err) {
    await client.query("ROLLBACK");
    req.log.error({ err }, "DE import error");
    res.status(500).json({ error: "Import failed" });
    return;
  } finally {
    client.release();
  }

  const total = await pool.query("SELECT COUNT(*) FROM entities");
  res.json({
    imported: inserted,
    skipped,
    total_in_db: parseInt(total.rows[0].count, 10)
  });
});

export default router;
